require "install/version"

module Install
  class Error < StandardError; end
  # Your code goes here...
end
